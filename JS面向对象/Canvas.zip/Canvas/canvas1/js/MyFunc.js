var canvas = {

    randomNum: function (min, max) {
        return Math.floor(Math.random() * (max - min  + 1) + min);
    },
    randomColor: function () {
        var r = this.randomNum(0, 255);
        var g = this.randomNum(0, 255);
        var b = this.randomNum(0, 255);
        return "rgb(" + r + "," + g + "," + b + ")";
    }


};